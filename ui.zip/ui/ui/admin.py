from .models import EbayPriceFormula,EbaySellerItems,EbaySellerSearch
from django.contrib import admin

admin.site.register(EbayPriceFormula)
admin.site.register(EbaySellerItems)
admin.site.register(EbaySellerSearch)