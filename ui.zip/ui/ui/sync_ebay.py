from .db import get_ebay_items, query_set_to_list, get_all_active_sellers_account, \
				get_price_formula, get_existing_value, create_ebay_item,set_ebay_items_to_inactive, \
				create_batchlog_item, create_run_item
from .utils import get_simple_list_from_list_dict, get_value_from_dict, \
				 make_amazon_url, get_float,get_run_id
from .factory import get_ebayhandler, get_amazonscraper, get_proxyhandler
from .helpers import is_value_empty
from .parsers import parse_ebay_item
import re
from django.forms.models import model_to_dict
from .models import EbaySellerItems,SellerTokens
import csv




def get_active_seller_account(current_user,is_active):
	seller_accounts = get_all_active_sellers_account(user_id=current_user,is_active=is_active)
	seller_accounts = query_set_to_list(seller_accounts)
	return seller_accounts


def get_total_no_of_pages(ebay_handler):
	o = ebay_handler.get_all_items()
	no_of_pages = get_value_from_dict(o,["ActiveList","PaginationResult","TotalNumberOfPages"])
	return no_of_pages


def get_ebay_item_list(ebay_handler,page = 1):
	ebay_items_list = []
	if ebay_handler:
		ebay_items_list = ebay_handler.get_all_items(page_number=page)
	return ebay_items_list


def get_ebay_items_list_from_ebay_response(ebay_response):
	if ebay_response:
		ebay_items_list = get_value_from_dict(ebay_response,["ActiveList","ItemArray","Item"])
		if not isinstance(ebay_items_list,list):
			ebay_items_list = [ebay_items_list]
	return ebay_items_list


def insert_data(seller_id,seller_token):
	# current_user = '1'
	# all_seller_account_of_current_user = get_active_seller_account(current_user,1)
	# if all_seller_account_of_current_user:
		# for seller_accounts in all_seller_account_of_current_user:

			# current_seller_id = seller_accounts.get("id")
			# is_set = set_ebay_items_to_inactive(current_seller_id)
			# if not is_set:
				# continue
			# current_seller_formula = get_price_formula(seller_id=current_seller_id)
			
			# if not current_seller_formula:
				# print("formula for current seller not found skipping......")
				# continue 
			# seller_accounts = SellerTokens.objects.get(pk = seller_id)
			# seller_token = seller_accounts.get("token")
			print("seller token",seller_token)
			if not seller_token:
				print("seller_token not found for current seller account skipping...." )
				exit(0)
			# set_ebay_items_to_inactive(seller_id)
			ebay_handler = get_ebayhandler(seller_token)
			no_of_pages = get_total_no_of_pages(ebay_handler)
			if no_of_pages and int(no_of_pages)>0:
				no_of_pages = int(no_of_pages)
				lst=[]					
				for page in range(1,no_of_pages+1):
					ebay_items_response = get_ebay_item_list(ebay_handler,page)
					ebay_items = get_ebay_items_list_from_ebay_response(ebay_items_response)

					if not ebay_items and isinstance(ebay_items,list):
						print("invalid ebay_items list")
						continue
					for item in ebay_items:
						parsed_data = parse_ebay_item(item,seller_id)
						print("parsed data",parsed_data)
						try:
							ebay_obj,created = EbaySellerItems.objects.get_or_create(**parsed_data)
							ebay_obj.is_active = True
							ebay_obj.save()
						except Exception as e:
							print("error in create_ebay_item",e)
							# input("presss enter")
							try:
								parsed_data["product_name"] = "title contains some latin word, not able to parse"
								ebay_obj,created = EbaySellerItems.objects.get_or_create(**parsed_data)
								ebay_obj.is_active = True
								ebay_obj.save()
							except Exception as e:
								print("second error..",e)
								# input("presss enterssssssssssssss")

								pass

						# input("press enter")
# testing_facade()
